## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebrewConstituencyParser
##
##    HebrewConstituencyParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebrewConstituencyParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebrewConstituencyParser.  If not, see <http://www.gnu.org/licenses/>.

"""
Binarize Linguistic Trees

a -> b c d e   ==>   a -> b c`   c` -> c d`  d` -> d e

a -> b c d e   ==> a -> b a'  
"""

import tree
from copy import copy

def rightBinarize(t):
   if isinstance(t, tree.Leaf):
      return copy(t)
   else:
      assert isinstance(t, tree.LingTree)
      child_names = [c.get_name() for c in t.childs]
      left = child_names[0]
      right = "^".join(child_names)
      t.childs


s1 = u"""
((a (b c) (d e) (f (g h))))
"""
t = tree.LingTree.from_str(s1)

rightBinarize(t)
