# coding:utf8
## Copyright 2010,2011 Yoav Goldberg
##
## This file is part of HebrewConstituencyParser
##
##    HebrewConstituencyParser is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    HebrewConstituencyParser is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with HebrewConstituencyParser.  If not, see <http://www.gnu.org/licenses/>.

from collections import defaultdict
from codecs import open
import re
import sys

#import sys; import os; sys.path.append(os.path.join(os.path.dirname(__file__),"../lattice"))
#from translate import heb2tb

def _ortography_heuristics(token):#{{{
   DEF=''
   if token and token[0]==u'ה': # be like the rest of the lexicon: allow the definite form..
      DEF='DEF'
      token=token[1:]
   if re.match(r"[0-9]+$",token):
      yield DEF+"_CD_"
   elif re.match(r"[0-9]*[.,][0-9]+[,0-9]*$",token):
      yield DEF+"_CD_"
      if token.find(",") == -1: yield DEF+"_NCD_"
   elif re.match(r"[0-9.:]+$",token): # : or more than one "."
      if token != ".":
         yield DEF+"_NCD_"
   elif re.match(r"[^0-9]*\.[^0-9]*$",token): # dot, but no numbers
      if token != '.': yield DEF+"_NNP_"#}}}

class DataDrivelLexicon:
   def __init__(self, twcount_fname,retrans=True,short=False):
      wc=defaultdict(float)
      tc=defaultdict(float)
      wtc=defaultdict(list)
      twcount_file=open(twcount_fname,encoding="utf8")
      for i,line in enumerate(twcount_file):
         if short and i>10000: break
         try:
            c,t,w=line.strip().split()
            t = t.replace(":","_")
         except:
            print >> sys.stderr, "skipping line:",line.encode("utf8")
         c=float(c)
         #if retrans: w=heb2tb(w)
         ortos = list(_ortography_heuristics(w))
         if ortos: continue
         else:
            wc[w]+=c
            tc[t]+=c
            wtc[w].append((t,c))
      twcount_file.close()
      self.wc=dict(wc)
      self.tc=dict(tc)
      self.wtc=dict(wtc)

   def get_tags_tgws(self,word):
      ortos = list(_ortography_heuristics(word))
      if ortos: 
         return ["%s/%s" % (t,1.0) for t in ortos]
      if word in self.wtc:
         return ["%s/%s" % (t,c/self.wc[word]) for t,c in self.wtc[word]]
      return []

   def get_tags_wgts(self,word):
      ortos = list(_ortography_heuristics(word))
      if ortos: 
         return ["%s/%s" % (t,1.0) for t in ortos]
      if word in self.wtc:
         return ["%s/%s" % (t,c/self.tc[t]) for t,c in self.wtc[word]]
      return []

if __name__=='__main__':
   WORDCOUNTS_FILE=os.path.join(os.path.dirname(__file__),"../wordprobs/morph1_tags.twcount")
   lex=DataDrivelLexicon(WORDCOUNTS_FILE)
   print lex.get_tags_wgts('ANFIM')
   print lex.wtc['ANFIM']
   print lex.tc['NN_M']
   print lex.wc['ANFIM']
   print lex.get_tags_wgts('1929') 
