#coding:utf-8
import sys
import cStringIO as StringIO
import codecs
import subprocess
import os.path
import il.ac.idc.nlp.constit.Parser as Parser

sys.path.append(os.path.join(os.path.dirname(__file__),'code'))
sys.path.append(os.path.join(os.path.dirname(__file__),'utils'))

from makelattice import tbanalyzer, SentenceLat
from lexify import annotate_lattices
from cleantrees import cleantreeline
import hebtokenizer


class PyParser(Parser):
    def __init__(self):
        (self.utf8_encode, self.utf8_decode, self.utf8_reader, self.utf8_writer) = codecs.lookup('utf-8')        

        
        allowed_tags_file=file(os.path.join(os.path.dirname(__file__),"training_tags"))
        self.allowed_tags = set([l.strip() for l in allowed_tags_file])
        allowed_tags_file.close()
        
        self.analyzer = tbanalyzer.AnalyzerWpos(always_include_full=False)

    def parse_sent(self,utf8_sent, tokenized=True):
        if tokenized:
            words = utf8_sent.split()
        else:
            words = [tok for (which,tok) in hebtokenizer.tokenize(utf8_sent)]
        slat = SentenceLat(self.analyzer,words)
        lattice = StringIO.StringIO()
        slat.as_seg_lat(lattice, lambda x:x)
        problattice=StringIO.StringIO()
        lattice.seek(0)
        annotate_lattices(self.utf8_reader(lattice),False,problattice)
        return problattice.getvalue().decode("utf-8")
