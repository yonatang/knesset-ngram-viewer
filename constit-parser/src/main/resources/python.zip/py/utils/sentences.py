#!/usr/bin/env python
import codecs
import sys

from optparse import OptionParser
parser = OptionParser("%prog [options] < in_file > out_file")
parser.add_option("-i","--ie",help="input encoding [default %default]",dest="in_enc",default="utf_8_sig")
parser.add_option("-o","--oe",help="output encoding [default %default]",dest="out_enc",default="utf_8")
parser.add_option("-f","--fix_punct",help="add sentence-final period if missing",dest="add_final_period",action='store_true', default=False)
opts, args = parser.parse_args()

for line in codecs.getreader(opts.in_enc)(sys.stdin):
   line = line.strip().replace(". ",".\n").replace("? ","?\n").replace("! ","!\n")
   sents = line.split("\n")
   for sent in sents:
      sent = sent.strip()
      if sent: 
         if opts.add_final_period and sent[-1] not in u'.,?!;:': 
            print sent.encode(opts.out_enc),u"."
         else:
            print sent.encode(opts.out_enc)



